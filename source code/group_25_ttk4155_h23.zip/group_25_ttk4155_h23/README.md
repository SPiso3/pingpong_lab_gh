https://github.com/SPiso3/pingpong_lab_gh \
Repository for ping-pong mechatronic embedded system for TTK4155.

### Group 25
Alberto Morselli https://github.com/albertomors \
Sergio Pisoni https://github.com/SPiso3 \
Adrià Espiell Chaler

### Highlights
Hours spent on this: approx 110 \
Best push: 13nov2024 from 8:30🕣 to 22:30🕥