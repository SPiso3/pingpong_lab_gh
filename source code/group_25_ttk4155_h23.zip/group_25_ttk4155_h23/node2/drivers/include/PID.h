#ifndef PID_H_
#define PID_H_

#include "sam3x8e.h"
#include <stdio.h>

int32_t pid(int32_t r, int32_t y);

#endif /* PID_H_ */