#ifndef UTILS_H_
#define UTILS_H_

#include "drivers/include/encoder.h"
#include "drivers/include/motor.h"
#include "drivers/include/time.h"
#include <stdio.h>

void auto_calib_encoder();

#endif /* UTILS_H_ */